# Assessment Artifacts

The graded work I completed across the course, with a short note on the outcome or key takeaway of each. This is the evidence of performance and progress that sits behind the reflections and project docs.

## Theory assignments

| Assignment | Focus | Outcome / takeaway |
|---|---|---|
| **Telecommunications Fundamentals** | Definitions, network components, analog vs digital, communication types, topologies | Built the core vocabulary and the trade-off way of thinking (esp. topology performance vs reliability vs scalability). |
| **5G Core Architecture** | EPC vs 5GC, network slicing, MEC, AI resource allocation, NRF | Reframed the network as software with a service-based core; set up the slicing and MEC ideas the labs later used. |
| **Open RAN / RIC / SON** | AI/ML in the RAN, SON, Traditional vs Open RAN, Near-RT vs Non-RT RIC | Learned where intelligence sits in a disaggregated RAN and what each RIC timescale controls. |

## Labs

| Lab | Deliverable | Headline result |
|---|---|---|
| **Lab 2 — RF Propagation & Wireshark** | FSPL model + protocol capture | Coverage cost made visual; protocol behavior observed live. |
| **Lab 3.1 — Random Forest Traffic Prediction** | Report with real metrics | Test R² **0.893**, MSE **34.64**. |
| **5G Slice Allocation** | Simulation report | 500 units → URLLC 139 / eMBB 278 / mMTC 82. |
| **Lab 4 — Time-Series Forecasting** | ARIMA / LR / LSTM comparison | Found & fixed a data-leakage bug; corrected one-step R² ≈ 0.79. |
| **Lab 5 — Edge / Model Compression** | Prune / quantize / distill | 51 KB → 4.9 KB (10.49×); caught two flaws in the provided pipeline. |

Full write-ups for all labs are in **[../projects/](../projects/)**.

## AI Ethics assignment

A 30-question assignment written in first-person prose, worked against the major governance frameworks:

- **IEEE Ethically Aligned Design**
- **OECD's five AI principles**
- **UNESCO 2021 Recommendation on the Ethics of AI**
- **EU AI Act** four-tier risk classification

Takeaway: I stopped treating fairness, transparency, and accountability as add-ons and started treating them as requirements on the same footing as latency or reliability.

## Case studies (Module 13)

| Case | Ethical issue | What I drew from it |
|---|---|---|
| **COMPAS** | Bias in criminal sentencing; opacity | Fairness and transparency failures compound each other. |
| **Cambridge Analytica** | Data privacy, consent, manipulation | Consent and data rights are engineering constraints, not fine print. |
| **Autonomous vehicles** | The trolley problem in real time | Some decisions can't be optimized away — they need explicit, governed standards. |
| **Generative AI** | Misinformation, authorship, copyright | Authenticity and provenance are becoming first-class requirements. |

## Reading that shaped my thinking

Two survey papers I used to place the labs in the wider research landscape:

- Sheraz et al. (2024), *A Comprehensive Survey on Revolutionizing Connectivity Through AI-Enabled Digital Twin Network in 6G*, IEEE Access. — grounded my understanding of digital twins, and how AI-DTN drives resource allocation, caching, offloading, and security in 6G.
- Katsaros et al. (2024), *AI-Native Multi-Access Future Networks — The REASON Architecture*, IEEE Access. — a full 6G reference architecture; taught me to read a layered systems design (AI/Cognitive planes, mATRIC, E2E orchestration) as reasoning rather than acronyms.
