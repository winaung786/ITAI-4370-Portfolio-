# Reflection 3 — Skills I Improved and Where I Want to Grow

## What actually got better

**Reading a system before touching it.** Early on I'd jump straight into code. By the middle of the course I'd started doing what the RF and 5G modules trained into me: figure out the constraint first, then decide what to build. That habit is why the slicing and compression labs went smoothly — I understood *why* a slice needed a certain amount of resource before I let a model near it.

**Debugging results, not just code.** The single most valuable skill I picked up came from the data-leakage bug in the time-series lab. Code that runs is not code that's correct, and a good-looking metric is exactly when you should be most suspicious. I now instinctively ask where the labels could be sneaking into the features, whether the train/test split respects time, and whether two numbers I'm comparing were even produced by the same task. That skepticism transfers far beyond this course.

**Turning a run into a defensible report.** I got a lot more fluent at moving from "the script printed some numbers" to "here is the result, here is how it was produced, and here is the one caveat you should know." Reporting the broken *and* fixed leakage numbers, or flagging that ARIMA's multi-step forecast wasn't comparable to the one-step models, made my write-ups something I'd actually stand behind.

**The AI-native networking picture.** From the 6G and digital-twin readings I came away able to place a technique in the bigger architecture — where federated learning fits for privacy, why a digital twin is useful as a safe sandbox for testing AI before it touches the live network, what a RIC is actually controlling. I can now read a systems paper like the REASON architecture and follow the design reasoning instead of drowning in acronyms.

**Taking ethics seriously as engineering.** The ethics assignment and Module 13 shifted this from a checkbox to a real design input for me. Working through COMPAS, Cambridge Analytica, and the autonomous-vehicle cases against frameworks like the OECD principles and the EU AI Act's risk tiers, I stopped treating fairness and transparency as add-ons and started seeing them as requirements, the same as latency or reliability.

## Where I want to grow next

- **Deeper time-series modeling.** My LSTM worked, but I built it fairly mechanically. I want to understand sequence models — attention, proper multi-horizon forecasting, uncertainty estimates — well enough to design them, not just assemble them.
- **Reinforcement learning for real control loops.** The RIC and SON material hinted at RL running closed-loop optimization in the RAN. I've only touched tabular Q-learning; I'd like to work up to policy methods on an actual network-control problem.
- **Deployment, end to end.** I can compress a model now, but I haven't run one on real edge hardware under a live traffic load. Closing that gap — from trained model to something serving on a constrained device — is the next honest step.
- **Reproducibility discipline.** I want to get consistent about seeds, environment capture, and experiment logging so that "I ran it and got X" is something anyone can verify, not just me.

The course gave me a working map of where AI meets the network. The growth I'm after now is depth in the few places on that map I found most compelling — forecasting, control, and getting models to actually run where the network needs them.
