# Growth Evidence — From Basic Concepts to Advanced AI Applications

This is the throughline of the portfolio: concrete evidence that I moved from foundational telecom concepts to advanced AI applications, and that the course content is what drove the change. Each stage lists what I could do at the start of it and what I could do by the end.

## The progression, module by module

| Stage | Modules | Starting point | Ending point (evidence) |
|---|---|---|---|
| **1. Foundations** | 1–2 | Described networks only as a user ("signal bars"). | Reasoned about topology trade-offs and modeled RF path loss from first principles; read live protocol traffic in Wireshark. |
| **2. 5G systems** | 3–4 | Saw "5G" as a faster generation. | Explained the service-based 5G core, network slicing, and MEC; simulated slice allocation across URLLC/eMBB/mMTC. |
| **3. Intelligence in the RAN** | 5–6 | Thought of AI and networking as separate subjects. | Placed AI/ML inside the RAN (Open RAN, RIC timescales, SON); built a Random Forest traffic predictor at R² 0.893. |
| **4. Applied ML** | 7 | Could run a model but not critique it. | Built ARIMA/LR/LSTM forecasters, caught a data-leakage bug, and compressed a model 10.49× for edge deployment — while flagging the pipeline's flaws. |
| **5. Frontier & responsibility** | 10–13 | No framework for ethics or 6G architecture. | Analyzed AI-ethics cases against OECD/EU AI Act frameworks; read the REASON and DTN survey architectures as design reasoning. |

## Three concrete before/after snapshots

**From "signal bars" to a path-loss budget.**
At the start I couldn't say why coverage is hard. After the RF lab I could plot the loss curve, explain why doubling range is disproportionately expensive, and connect that to why higher-frequency 5G/6G bands need denser deployments.

**From "run the model" to "distrust the metric."**
Early on, a high score was a good score. The turning point was the time-series lab's perfect R² = 1.0 — I learned to trace it to a data-leakage bug, fix it, and report a realistic ~0.79 instead. I now check for label leakage, time-respecting splits, and fair task comparisons by reflex. That's the single clearest jump in skill in the whole course.

**From "compression is magic" to "compression is a measured trade-off."**
In Lab 5 I not only shrank a 51 KB model to under 5 KB, I caught that the advertised 4× quantization gain didn't hold on disk and that the provided "distillation" never applied its own loss. Going from consuming a technique to auditing it is exactly the basic → advanced move the course was built to produce.

## How the course content drove it

None of this was self-taught in a vacuum. The topology and RF modules gave me the trade-off lens; the 5G core and Open RAN modules gave me the systems vocabulary; the applied-ML labs forced the rigor; and the ethics and 6G modules gave me the frame to judge where all of it *should* go. The progression above is the course's structure showing up in what I can now do.
