# Project Documentation

Detailed documentation of the practical work I did in ITAI 4370. Each entry follows the same shape: **problem statement → methods and tools → code → results → interpretation.** Figures are generated from my own runs.

**Contents**
1. [RF Propagation & Protocol Analysis (Lab 2)](#1-rf-propagation--protocol-analysis-lab-2)
2. [Random Forest Traffic Prediction (Lab 3.1)](#2-random-forest-traffic-prediction-lab-31)
3. [AI-Driven 5G Network Slice Allocation](#3-ai-driven-5g-network-slice-allocation)
4. [Time-Series Traffic Forecasting (Lab 4)](#4-time-series-traffic-forecasting-lab-4)
5. [Edge Computing & Model Compression (Lab 5)](#5-edge-computing--model-compression-lab-5)
6. [Simulation Sandbox — SimPy, Mesa, and Energy/RL (Modules 10–11)](#6-simulation-sandbox--simpy-mesa-and-energyrl-modules-1011)

---

## 1. RF Propagation & Protocol Analysis (Lab 2)

**Problem statement.** Quantify how a wireless signal weakens with distance, and observe real protocol behavior on the wire rather than in a diagram.

**Methods and tools.** Python (NumPy, Matplotlib) for the Free-Space Path Loss model; Wireshark for a live packet capture and protocol dissection. The FSPL model uses the standard log-distance form:

```
FSPL(dB) = 20·log10(d_km) + 20·log10(f_MHz) + 32.44
```

**Code (core of the model):**
```python
import numpy as np
import matplotlib.pyplot as plt

d = np.linspace(0.1, 20, 200)      # distance in km
f_mhz = 2400.0                      # 2.4 GHz
fspl = 20*np.log10(d) + 20*np.log10(f_mhz) + 32.44

plt.plot(d, fspl, label="FSPL @ 2.4 GHz")
plt.xlabel("Distance (km)"); plt.ylabel("Path loss (dB)")
plt.legend(); plt.show()
```

**Results.**

![FSPL vs distance](../assets/fspl.png)

**Interpretation.** The loss curve is steep near the transmitter and keeps rising with distance, which is exactly why cell coverage is expensive to extend and why higher frequencies (which start with more loss) need denser deployments. Pairing the model with the Wireshark capture connected the math to observable behavior — I could see the handshake and control traffic that the path-loss budget ultimately has to carry.

---

## 2. Random Forest Traffic Prediction (Lab 3.1)

**Problem statement.** Predict short-term network traffic load from recent history so a controller could provision resources ahead of demand.

**Methods and tools.** Python, scikit-learn (`RandomForestRegressor`), pandas, Matplotlib. Lagged traffic values were used as features; the model was evaluated on a held-out test split with R² and MSE.

**Results (logged run):**

| Metric | Value |
|---|---|
| Test R² | **0.893** |
| Test MSE | **34.64** |

![Random Forest traffic prediction](../assets/rf_traffic.png)

**Interpretation.** A Random Forest on honest lag features already captures most of the structure in the traffic signal (R² ≈ 0.89). This became my baseline intuition for the harder time-series lab later: tree ensembles on good features are a strong, hard-to-beat starting point, and any fancier model has to justify its added complexity against them.

---

## 3. AI-Driven 5G Network Slice Allocation

**Problem statement.** Given one physical network and a fixed pool of 500 resource units, allocate capacity across three slices with different service requirements — URLLC (latency-critical), eMBB (throughput-heavy), mMTC (massive low-rate IoT).

**Methods and tools.** Python simulation of per-slice demand and a resource allocator that distributes the pool according to each slice's traffic profile and priority.

**Results (logged run):**

| Slice | Units allocated | Character |
|---|---|---|
| URLLC | 139 | Latency-critical, moderate volume |
| eMBB | 278 | Bandwidth-dominant |
| mMTC | 82 | Many devices, low per-device rate |
| **Total** | **500** | |

![Slice allocation](../assets/slicing.png)

**Interpretation.** eMBB claims the largest share because throughput is expensive, while mMTC needs relatively little despite serving the most devices. Seeing the allocation respond to slice *character* rather than a fixed split is the essence of intelligent resource management in the 5G core — the same idea a learned controller scales up in a real RAN.

---

## 4. Time-Series Traffic Forecasting (Lab 4)

**Problem statement.** Forecast hourly network traffic over a year of synthetic data and compare classical and deep-learning approaches fairly.

**Methods and tools.** Python, pandas, statsmodels (ARIMA), scikit-learn (Linear Regression), and a PyTorch LSTM I implemented from scratch (the lab left the LSTM as a conceptual stub). Pipeline: synthetic data generation → EDA and seasonal decomposition → ADF stationarity test → three models → held-out evaluation.

**The bug worth documenting.** The provided feature-engineering code produced a suspiciously perfect **R² = 1.0**. Tracing it, the rolling moving-average features included the *current* timestep — a textbook data-leakage bug, where the target is partly recoverable from the features. I implemented a leakage-free version and reported both.

```python
# LEAKY (includes current timestep in the window):
df["ma3"] = df["traffic"].rolling(3).mean()

# CORRECTED (shift so only past values are used):
df["ma3"] = df["traffic"].shift(1).rolling(3).mean()
```

**Results (corrected run):**

| Model | Task | Test R² |
|---|---|---|
| ARIMA(2,1,2) | multi-step forecast | −2.86 |
| Linear Regression (corrected) | one-step ahead | **0.793** |
| LSTM (from scratch) | one-step ahead | 0.776 |

![Lab 4 model comparison](../assets/lab4_r2.png)

**Interpretation.** Two honest caveats matter more than the leaderboard. First, ARIMA's negative R² is not evidence it's a bad model — a non-seasonal ARIMA forecasting far ahead in one shot flattens toward the mean while real traffic keeps cycling, so it's solving a genuinely harder task than the one-step models. Comparing them head-to-head would be misleading. Second, the corrected Linear Regression essentially ties the LSTM: with honest lag features, a simple model is a very strong baseline, and the deep model has to earn its keep. The most instructive part of this lab wasn't a model — it was learning to distrust a perfect score.

---

## 5. Edge Computing & Model Compression (Lab 5)

**Problem statement.** Take a trained IoT-sensor classifier and make it small enough to run on a constrained edge device, without giving up meaningful accuracy.

**Methods and tools.** Python, TensorFlow (CPU, in a virtualenv), TensorFlow Lite for INT8 quantization. Four models were trained/evaluated: a full-precision baseline, a structurally pruned model, an INT8-quantized TFLite model, and a distilled student network.

**Results (logged run):**

| Model | Accuracy | Size on disk | Compression |
|---|---|---|---|
| Baseline (FP32) | 94.25% | 51.3 KB | 1.00× |
| Pruned | 92.90% | 13.8 KB | 3.72× |
| INT8 quantized (TFLite) | 93.20% | 21.8 KB | 2.36× |
| Distilled student | 91.70% | 4.9 KB | 10.49× |

![Compression vs accuracy](../assets/compression.png)

**Two findings I'm proud of catching.**
1. The lab claimed a clean 4× reduction from INT8 quantization, but at the *file* level it only realized 2.36×. On a small model the TFLite container overhead dilutes the weight-level saving — the 4× is a weights-only figure, not an on-disk one.
2. The provided distillation code never actually applied its distillation loss, so the "distilled" model was just a small network trained on hard labels. I implemented genuine temperature-scaled knowledge distillation for comparison; it landed at **90.95%**, slightly *worse*, because on an easy task the soft targets add little value over hard labels.

**Interpretation.** Each compression technique trades a little accuracy for a lot of size, but the trades aren't equal and the advertised numbers don't always survive contact with a real file. The distillation result is the useful lesson: a more sophisticated method is only worth it when the problem is hard enough to need it.

---

## 6. Simulation Sandbox — SimPy, Mesa, and Energy/RL (Modules 10–11)

**Problem statement.** Build small conceptual models of network behavior — packet flow, adaptive routers, and energy-aware control — to make the advanced-module ideas concrete.

**Methods and tools.** Python with SimPy (discrete-event packet simulation through a chain of routers), Mesa (agent-based router-load model on a small-world graph), plus SciPy `linprog` for energy-source allocation and a tabular Q-learning agent for an energy-vs-QoS control policy.

**Representative code (Q-learning energy/QoS policy):**
```python
states  = ["low_traffic", "medium_traffic", "high_traffic"]
actions = ["sleep", "normal", "boost"]
# reward table trades energy savings against QoS, e.g.
# ("low_traffic","sleep"): +10 ; ("high_traffic","sleep"): -20
Q = np.zeros((len(states), len(actions)))
alpha, gamma = 0.1, 0.9
# ... update Q over episodes, then read off the greedy policy per state
best = {s: actions[np.argmax(Q[i])] for i, s in enumerate(states)}
```

**Interpretation.** These aren't production systems — they're the smallest possible versions of the ideas in the advanced modules. The SimPy and Mesa models made "digital twin" and "self-organizing network" tangible, and the energy/RL snippets connected directly to the 6G sustainability theme: a controller learning to sleep cells under low load is the toy version of the energy-aware optimization those architectures are chasing.
