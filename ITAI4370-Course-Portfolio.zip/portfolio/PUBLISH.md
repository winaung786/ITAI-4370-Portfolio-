# How to Publish This Portfolio (get your live shareable link)

This repo is ready to go live. Pick **one** of the two options below — both are free and give you a shareable link.

## Option A — GitHub repository (fastest, renders Markdown automatically)

1. Create a free account at github.com if you don't have one.
2. Create a new **public** repository, e.g. `itai4370-course-portfolio`.
3. Upload these files/folders (keep the structure), or from a terminal:
   ```bash
   git init
   git add .
   git commit -m "ITAI 4370 Course Portfolio"
   git branch -M main
   git remote add origin https://github.com/<your-username>/itai4370-course-portfolio.git
   git push -u origin main
   ```
4. Your live link is the repo URL: `https://github.com/<your-username>/itai4370-course-portfolio`
   GitHub renders `README.md` as the homepage and all internal links work.

## Option B — GitHub Pages (nicer website look)

1. Do everything in Option A first.
2. In the repo, go to **Settings → Pages**.
3. Under "Build and deployment," set **Source: Deploy from a branch**, **Branch: main**, **Folder: /(root)**, then Save.
4. After a minute your site is live at:
   `https://<your-username>.github.io/itai4370-course-portfolio/`

## Before you submit — fill these in

- Add your live link to the top of `README.md`.
- Replace any placeholder dates if needed (currently July 7, 2026).
- Keep it updated: since the brief asks for a "continuously updated" portfolio, commit any new artifacts as the course finishes.

That published link is the deliverable to hand in.
